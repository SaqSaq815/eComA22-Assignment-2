<?php
	session_start();
	require("app/core/autoload.php");